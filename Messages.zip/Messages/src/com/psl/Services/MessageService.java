package com.psl.Services;
import java.util.List;

import com.psl.Beans.*;

public interface MessageService {
	
	public List<Messages> getAllMessages();
	public int saveMessage(Messages m);
	public int deleteMessage(int id);
	public Messages searchMessage(int id);
	public int updateMessage(int id,String msg,String author);

}
