package com.psl.Services;

import java.util.List;
import java.util.ArrayList;

import com.psl.Beans.*;

public class MessageServiceImpl implements MessageService {
	private List<Messages> li = new ArrayList<Messages>();
	MessageServiceImpl msg=null;

	
	private static MessageServiceImpl single_instance = null;

	private MessageServiceImpl() {
	}

	public static MessageServiceImpl getInstance() {
		if (single_instance == null)
			single_instance = new MessageServiceImpl();

		return single_instance;
	}

	
	public List<Messages> getAllMessages() {
		int id=1;
		String str="Hello world";
		String auth="Simran";
		if(li==null)
		{
			Messages msg=new Messages(id,str,auth);
			li.add(msg);
		}
		return li;

	}

	@Override
	public int saveMessage(Messages message) {
		msg=new MessageServiceImpl();
	for(Messages m:msg.getAllMessages())
	{
		if(m.equals(message))
		{
			return 0;
		}
		else
			li.add(message);
		return 1;
	}
		
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public int updateMessage(int id,String message,String author) {
		Messages msg2=new Messages();
		msg=new MessageServiceImpl();
		for(Messages m:msg.getAllMessages())
		{
			if(m.getId()==id)
			{
				m.setAuthor(author);
				m.setMsg(message);
				return 1;
			}
			else
				
			return 0;
		}
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteMessage(int id) {
		msg=new MessageServiceImpl();
		for(Messages m:msg.getAllMessages())
		{
			if(m.getId()==id)
			{
				li.remove(m);
				return 1;
			}
			else
				
			return 0;
		}
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Messages searchMessage(int id) {
		for(Messages m:msg.getAllMessages())
		{
			if(m.getId()==id)
			{
				
				return m;
			}
			else
				
			return null;
		}
		
		// TODO Auto-generated method stub
		return null;
	}

}
