package com.psl.Rest;

import java.io.IOException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.psl.Beans.Messages;
import com.psl.Services.MessageServiceImpl;
import com.sun.research.ws.wadl.Application;

@Path("/MessageRest")
public class MessageRest {
	private static final String SUCCESS_RESULT = "Success";
	private static final String FAILURE_RESULT = "Failure";
	MessageServiceImpl msg = MessageServiceImpl.getInstance();

	@GET
	@Path("/messages")
	@Produces(MediaType.APPLICATION_XML)
	public List<Messages> getUsers() {
		return msg.getAllMessages();
	}

	@GET
	@Path("/messages/{id}")
	@Produces(MediaType.APPLICATION_XML)
	public Messages getMessage(@PathParam("userid") int id) {
		return msg.searchMessage(id);
	}

	@POST
	@Path("/messages")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String createMessage(Messages s) throws IOException {
		Messages m = new Messages(s.getId(), s.getMsg(), s.getAuthor());
		int result = msg.saveMessage(m);
		if (result == 1) {
			return SUCCESS_RESULT;
		}
		return FAILURE_RESULT;
	}
	
	@POST
	@Path("/messages1")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.TEXT_PLAIN)
	public String createMessage1(Messages s) throws IOException {
		Messages m = new Messages(s.getId(), s.getMsg(), s.getAuthor());
		int result = msg.saveMessage(m);
		if (result == 1) {
			return SUCCESS_RESULT;
		}
		return FAILURE_RESULT;
	}

	@PUT
	@Path("/messages/{id}")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_JSON)
	public String updatingMessage(@PathParam("userid") int id, Messages s) {
		int result = msg.updateMessage(s.getId(), s.getMsg(), s.getAuthor());
		if (result == 1) {
			return SUCCESS_RESULT;
		}
		return FAILURE_RESULT;

	}
	
	@DELETE
	@Path("/messages/{id}")
	@Produces(MediaType.APPLICATION_XML)
	public String deletingMessage(@PathParam("userid") int id){
		int result=msg.deleteMessage(id);
		if (result == 1) {
			return SUCCESS_RESULT;
		}
		return FAILURE_RESULT;

	}

}
