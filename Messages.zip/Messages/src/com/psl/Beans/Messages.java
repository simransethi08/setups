package com.psl.Beans;

//import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name = "Messages")

public class Messages{
	private int id;
	private String msg;
	private String author;
	
	
	public Messages() {
		//super();
	}
	public Messages(int id2, String msg2, String author2) {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	@XmlElement
	public void setId(int id) {
		this.id = id;
	}
	public String getMsg() {
		return msg;
	}
	@XmlElement
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getAuthor() {
		return author;
	}
	@XmlElement
	public void setAuthor(String author) {
		this.author = author;
	}
	
	 @Override
	   public boolean equals(Object object){
	      if(object == null){
	         return false;
	      }else if(!(object instanceof Messages)){
	         return false;
	      }else {
	    	  Messages message = (Messages)object;
	         if(id == message.getId()
	            && msg.equals(message.getMsg())
	            && author.equals(message.getAuthor())
	         ){
	            return true;
	         }			
	      }
	      return false;
	   }	

}
