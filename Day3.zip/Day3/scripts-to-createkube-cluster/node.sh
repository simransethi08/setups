#!/bin/bash
sudo yum install -y docker
sudo systemctl enable docker && systemctl start docker
cat <<EOF > /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://packages.cloud.google.com/yum/repos/kubernetes-el7-x86_64
enabled=1
gpgcheck=1
repo_gpgcheck=1
gpgkey=https://packages.cloud.google.com/yum/doc/yum-key.gpg https://packages.cloud.google.com/yum/doc/rpm-package-key.gpg
EOF
sudo setenforce 0
sudo yum install -y kubelet kubeadm kubectl
sudo yum install -y ebtables ethtool
sudo systemctl enable kubelet && systemctl start kubelet
sudo systemctl disable firewalld && systemctl stop firewall
sudo kubeadm join --token 0dc078.e895e279742a2965 172.31.81.230:6443 --discovery-token-ca-cert-hash sha256:11f1e52b58c7bc77344eb75d3d5cb2dbdadb99060d623da5ac36b9414fb1af14 --skip-preflight-checks
