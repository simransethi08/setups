#!/bin/bash
sudo yum install -y docker
sudo systemctl enable docker && systemctl start docker
cat <<EOF > /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://packages.cloud.google.com/yum/repos/kubernetes-el7-x86_64
enabled=1
gpgcheck=1
repo_gpgcheck=1
gpgkey=https://packages.cloud.google.com/yum/doc/yum-key.gpg https://packages.cloud.google.com/yum/doc/rpm-package-key.gpg
EOF
sudo setenforce 0
sudo yum install -y kubelet kubeadm kubectl
sudo yum install -y ebtables ethtool
sudo systemctl enable kubelet && systemctl start kubelet
sudo systemctl disable firewalld && systemctl stop firewall
sudo kubeadm init --skip-preflight-checks  --token-ttl 0
sudo echo $HOME
sudo mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config  
sudo chown $(id -u):$(id -g) $HOME/.kube/config
sudo export KUBECONFIG=$HOME/.kube/config
sudo kubectl apply -f https://git.io/weave-kube-1.6
sudo kubectl get pods --all-namespaces
sudo kubectl get nodes
